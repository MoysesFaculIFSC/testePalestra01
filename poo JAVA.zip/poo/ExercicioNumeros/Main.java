package ExercicioNumeros;

import java.util.List;

public class Main {
    public static void main(String[] args) {
//        ListaDeNumeros listaDeNumeros = new ListaDeNumeros(5,10);
//        System.out.println(listaDeNumeros.numeros());
//        System.out.println(listaDeNumeros.numeros());
        Numeros pares = new NumerosImpares(new NumerosOriginais(5,10));
        System.out.println(pares.numeros());

    }
}
