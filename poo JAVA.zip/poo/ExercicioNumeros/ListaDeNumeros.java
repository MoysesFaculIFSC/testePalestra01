package ExercicioNumeros;

import java.util.ArrayList;
import java.util.List;

public class ListaDeNumeros {
    private int inicio;
    private int fim;

    public ListaDeNumeros(int i, int f) {
        this.inicio = i;
        this.fim = f;
    }

    public List<Integer> numeros() {
        List<Integer> lista = new ArrayList<>();
        for (int i = this.inicio; i <= this.fim; i++){
            lista.add(i);
        }
        return lista;
    }
}
