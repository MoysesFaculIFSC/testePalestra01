package ExercicioNumeros;

import java.util.ArrayList;
import java.util.List;

public class NumerosImpares implements Numeros{
    private Numeros numeros;

    public NumerosImpares(Numeros numeros){
        this.numeros = numeros;
    }

    @Override
    public List<Integer> numeros() {
        List<Integer> impares = new ArrayList<>();
        for(int i : this.numeros.numeros()){
            if(i % 2 != 0)
                impares.add(i);
        }
        return impares;
    }
}
