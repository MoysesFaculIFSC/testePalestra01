package ExercicioNumeros;

import java.util.ArrayList;
import java.util.List;

public class NumerosPares implements Numeros{
    private Numeros numeros;

    public NumerosPares(Numeros numeros){
        this.numeros = numeros;
    }

    @Override
    public List<Integer> numeros() {
        List<Integer> pares = new ArrayList<>();
        for(int i : this.numeros.numeros()){
            if(i % 2 == 0)
                pares.add(i);
        }
        return pares;
    }
}
