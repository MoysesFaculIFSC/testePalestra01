package ExercicioNumeros;

import java.util.List;

public interface Numeros {
    public List<Integer> numeros();
}
