package ExercicioAdvinhaNumero;

public class Main {
    public static void main(String[] args) {
        Numero aleatorio = new NumeroAleatorio();
        Numero palpite = new NumeroPalpite();
        Numero diferenca = new Diferenca(aleatorio,palpite);
        DiferencaDetalhada diferencaDetalhada = new DiferencaDetalhada(diferenca);
        Tentativa tentativa = new Tentativa(diferencaDetalhada,50);

        JogoDeAdivinhacao jogo = new JogoDeAdivinhacao(tentativa,aleatorio);
        jogo.jogar();
    }
}
