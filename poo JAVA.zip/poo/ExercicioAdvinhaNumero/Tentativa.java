package ExercicioAdvinhaNumero;

public class Tentativa {
    private Numero diferenca;
    private int numeroDeTentativas;

    public Tentativa(Numero diferenca,int numeroDeTentativas){
        this.diferenca = diferenca;
        this.numeroDeTentativas = numeroDeTentativas;
    }

    public boolean acertou(){
        int tentativa = 0;
        while(tentativa < this.numeroDeTentativas){
            if(this.diferenca.numero() == 0) {
                return true;
            }
            tentativa++;
        }
        return false;
    }

}
