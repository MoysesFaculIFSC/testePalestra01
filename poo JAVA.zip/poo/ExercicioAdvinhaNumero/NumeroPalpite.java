package ExercicioAdvinhaNumero;

import java.util.Scanner;

public class NumeroPalpite implements Numero{
    @Override
    public int numero() {
        System.out.println("escolha um numero de 0 a 100");
        return new Scanner(System.in).nextInt();
    }
}
