package ExercicioAdvinhaNumero;

public interface Numero {
    int numero();
}
