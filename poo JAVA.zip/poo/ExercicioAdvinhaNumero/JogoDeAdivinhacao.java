package ExercicioAdvinhaNumero;

public class JogoDeAdivinhacao {
    private  Tentativa tentativa;
    private Numero numeroAleatorio;

    public JogoDeAdivinhacao(Tentativa tentativa,Numero numeroAleatorio){
        this.tentativa = tentativa;
        this.numeroAleatorio = numeroAleatorio;
    }

    public void jogar(){
        if(!this.tentativa.acertou()){
            System.out.println("vc errou");
        } else {
            System.out.println("vc acertou!");
        }
        System.out.println("Volte sempre!");
    }
}
