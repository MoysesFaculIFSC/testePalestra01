package ExercicioAdvinhaNumero;

public class DiferencaDetalhada implements Numero{
    private Numero diferenca;
    public DiferencaDetalhada(Numero diferenca){
        this.diferenca = diferenca;
    }

    @Override
    public int numero() {
        int numero = this.diferenca.numero();
        if(numero < 0)
            System.out.println("É menor!");
        else if (numero > 0) {
            System.out.println("É maior!");
        } else {
            System.out.println("Acertou!!!");
        }
        return numero;
    }
}
