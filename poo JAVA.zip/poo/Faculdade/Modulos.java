package Faculdade;

import java.util.ArrayList;
import java.util.List;

public class Modulos {
    private List<Modulo> lista;

    public Modulos(){
        this.lista = new ArrayList<>();
    }
    public void adicionar(Modulo novoModulo){
        this.lista.add(novoModulo);
    }

}
