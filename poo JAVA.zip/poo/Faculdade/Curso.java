package Faculdade;

import java.util.ArrayList;
import java.util.List;

public class Curso {
    private String nome;
    private List<Modulo> modulos;

    public Curso(String nome){
        this.nome = nome;
        this.modulos = new ArrayList<>();
    }

    public void adicionar(Modulo novoModulo){
        this.modulos.add(novoModulo);
    }

    public void remover(Modulo modulo){
        this.modulos.remove(modulo);
    }

    public void removerTodos(){
        this.modulos.clear();
    }

    public int cargaHoraria (){
        int total = 0;
        // para cada disciplina no meu conjunto de disciplinas
        for(Modulo m : this.modulos){
            total = total + m.cargaHoraria(); //acumule
        }
        return total;
    }

    public boolean estaConcluido(){
        if(this.modulos.isEmpty())
            return false;
        for(Modulo m : this.modulos){
            if(!m.estaConcluido())
                return false;
        }
        return true;
    }

}
