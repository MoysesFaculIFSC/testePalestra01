package Faculdade;

import java.util.ArrayList;
import java.util.List;

public class Modulo {
    private String nome;
    private List<Disciplina> disciplinas;

    public Modulo(String nome){
        this.nome = nome;
        this.disciplinas = new ArrayList<>();
    }

    public void adicionar(Disciplina novaDisciplina){
        this.disciplinas.add(novaDisciplina);
    }

    public void remover(Disciplina disciplina){
        this.disciplinas.remove(disciplina);
    }

    public int quantidade() {
        return disciplinas.size();
    }

    public void removerTodas(){
        this.disciplinas.clear();
    }

    public int cargaHoraria (){
        int total = 0;
    // para cada disciplina no meu conjunto de disciplinas
        for(Disciplina d : this.disciplinas){
            total = total + d.ch(); //acumule
        }
        return total;
    }

    public boolean estaConcluido(){
        if(this.disciplinas.isEmpty())
            return false;
        for(Disciplina d : this.disciplinas){
            if(!d.estaConcluida())
                return false;
        }
        return true;
    }
}
