package Faculdade;

public class Disciplina {
    private String nome;
    private int ch;
    private boolean estaConcluida;

    public Disciplina(String nome, int ch){
        this.nome = nome;
        this.ch = ch;
        this.estaConcluida = false;
    }

    public void concluir(){
        this.estaConcluida = true;
    }

    public boolean estaConcluida(){
        return estaConcluida;
    }

    public int ch(){
        return this.ch;
    }

}
