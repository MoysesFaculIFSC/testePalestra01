package Faculdade;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Disciplina poo =  new Disciplina("POO",80);
        Disciplina bdi =  new Disciplina("BDI",80);

        Modulo m1 = new Modulo("M1");
        m1.adicionar(poo);
        m1.adicionar(bdi);
        poo.concluir();
        System.out.println("carga horaria total: "+m1.cargaHoraria());
        System.out.println("modulo concluído? "+m1.estaConcluido());

        m1.remover(bdi);
        System.out.println("-REMOVIDO BDI-");

        System.out.println("carga horaria total: " + m1.cargaHoraria());
        System.out.println("modulo concluído? "+m1.estaConcluido());

    }
}