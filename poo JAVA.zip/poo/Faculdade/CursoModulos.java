package Faculdade;

public class CursoModulos {
    private String nome;
    private Modulos modulos;

    public CursoModulos(String nome){
        this.nome = nome;
        this.modulos = new Modulos();
    }

    public void adicionar(Modulo m){
        modulos.adicionar(m);
    }
}
