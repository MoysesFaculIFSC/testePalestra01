package Pedido;

public class Item {
    private Produto produto;

    private int quantidade;

    public Item(Produto p , int quantidade){
        this.produto = p;
        this.quantidade = quantidade;
    }

    public double subTotal(){
        return this.quantidade * produto.preco();
    }
}
