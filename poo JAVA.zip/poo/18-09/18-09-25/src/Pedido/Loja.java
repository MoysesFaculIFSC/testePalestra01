package Pedido;

public class Loja {
    public static void main(String[] args) {
        /*
            Produto caneta = new Produto("Caneta", 2);
            Produto lapis = new Produto("Lápis", 3);

            PedidoBasico pedidoBasico = new PedidoBasico("123", caneta);

            PedidoBasico pedidoBasico1 = new PedidoBasico("1234", lapis);
        */

        Produto caneta = new Produto("Caneta", 2);
        Produto lapis = new Produto("Lápis", 3);

        PedidoBasico pedidoBasico = new PedidoBasico("123");

        pedidoBasico.adicionar(caneta);
        pedidoBasico.adicionar(lapis);
        System.out.println(pedidoBasico.total());


        //System.out.println(pedidoBasico1.total());

    }
}
