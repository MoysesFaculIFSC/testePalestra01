package Pedido;

import java.util.ArrayList;
import java.util.List;

public class PedidoBasico {
    private String numero;
    //private double total();
    private List<Produto> produtos;

    /*
        public PedidoBasico(String numero, Produto produto){
            this.numero = numero;
            this.produto = produto;
    }
    */
    public PedidoBasico(String numero){
        this.numero = numero;
        this.produtos = new ArrayList<>();
    }

    public void adicionar(Produto produto){
        this.produtos.add(produto);
    }

    public double total(){
        double t = 0;

        for (Produto p : produtos) {
            t = t + p.preco();
        }

        //return produto.preco();
        return t;
    }

}
