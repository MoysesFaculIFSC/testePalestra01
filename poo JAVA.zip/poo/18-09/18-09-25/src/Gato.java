public class Gato implements Animal{
   private String som;

   public Gato(String som){
       this.som = "Miau Miau";
   }

    @Override
    public void som() {
        //System.out.println("Miau Miau");
        System.out.println(this.som);
    }
}
