package Nota;

public class NotaBasica implements Nota{
    private double valor;
    public NotaBasica(double valor){
        this.valor = valor;
    }
    @Override
    public double valor() {
        return this.valor;
    }
}