package Nota;

public class NotaValidada implements Nota{
    private Nota nota;

    public NotaValidada(Nota nota){
        this.nota = nota;
    }

    @Override
    public double valor() {
       double v = this.nota.valor();

        if (v > 10){
           v = 10;
        }
        else if (v < 0){
            v = 0;
        }

        return v;
    }
}
