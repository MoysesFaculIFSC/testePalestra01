package Nota;

public class Menu implements Nota{
    private Nota nota;

    /*
    public void NotaBasica(double valor){
        this.nota = nota.valor();
    }
    */
    @Override
    public double valor() {
        return 0;
    }
}
