package Nota;

public class Escola {
    public static void main(String[] args) {
        NotaBasica notaBasica = new NotaBasica(11);

        System.out.println(notaBasica.valor());

        Nota notaBasicaValidada = new NotaValidada(new NotaBasica(11));

        System.out.println(notaBasicaValidada.valor());
    }
}
