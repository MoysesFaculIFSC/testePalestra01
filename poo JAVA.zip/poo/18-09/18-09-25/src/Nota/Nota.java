package Nota;

public interface Nota {
    double valor();

}
