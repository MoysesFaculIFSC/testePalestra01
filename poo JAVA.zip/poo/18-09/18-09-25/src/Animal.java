public interface Animal {
    public void som();

}
