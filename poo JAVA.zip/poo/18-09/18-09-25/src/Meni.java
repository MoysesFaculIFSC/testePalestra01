import Nota.Menu;

import java.util.List;

public class Meni {
    private String titulo;
    private List<Opcao> opcoes;

    public Meni(String titulo){
        this.titulo = titulo;
        this.opcoes = new List<>();
    }
}
