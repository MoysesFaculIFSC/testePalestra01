public class Curso {
    private Aluno aluno;


}
