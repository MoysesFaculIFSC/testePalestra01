public class Pet {
    public static void main(String[] args) {
        //Animal a = new Cao();
        Animal a = new Gato("Miau Miau");


        a.som();
    }
}
