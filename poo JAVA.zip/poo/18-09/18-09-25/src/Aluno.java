public class Aluno {
    //public String nome;
    //String nome;
    private String nome;

    public Aluno(String nome){
        this.nome = nome;
    }

    /*
        public String getNome(){
            return this.nome;
        }
    */


}
