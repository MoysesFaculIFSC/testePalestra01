public class Opcao {
    private String titulo;


}
