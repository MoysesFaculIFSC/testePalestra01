public class Cao implements Animal{

    @Override
    public void som() {
        System.out.println("Au Au");
    }
}
