public class CaoMP3 implements Animal{
    private Animal animal;

    public CaoMP3(Animal animal){
        this.animal = animal;
    }

    @Override
    public void som() {
        this.animal.som();
    }
}
