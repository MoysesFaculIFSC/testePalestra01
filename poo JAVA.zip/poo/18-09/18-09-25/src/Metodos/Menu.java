package Metodos;

import Input.Input;

/**
 *
 * @author Moysés
 */
public class Menu {

    public static int menuRegioes(){
        int op;
        //double y;
        String str;

        str = """
            Tabela de Regioes
            Codigo   Regioes
                1     Norte
                2     Nordeste
                3     Centro-Oeste
                4     Sudeste
                5     Sul
            """;
        //System.out.println(str);
        op = Input.inI(str + "Informe o código para Escolher a Região: ");

        return op;
    }

    public static int menuExercicios(){
        int op;
        //double y;
        String str;

        str = """
              
         |--------------------------|
         |  Tabela de Exercicios    |
         |--------------------------|
         |  Codigo | Exercicios     |
         |     1   | Exercicios01   |
         |     2   | Exercicios02   |
         |     3   | Exercicios03   |
         |     4   | Exercicios04   |
         |     5   | Exercicios05   |
         |     0   | Finalizar      |
         |--------------------------|
                            
            """;
        //System.out.println(str);
        op = Input.inI(str + "\nEscolha um Codigo de Exercicio para executar: ");

        return op;
    }

    public static int menuPrincipal(){
        int op;
        //double y;
        String str;

        str = """
            Menu Principal
            
                1  -  Lançar Nota
                2  -  Matricular
                0  -  Sair
            """;
        //System.out.println(str);
        op = Input.inI(str + "Informe o código para Escolher a Região: ");

        return op;
    }



}
