package banco.v10;

public class ContaComLimite implements Conta{
    private double limite;
    private Conta conta;

    public ContaComLimite(double limite, Conta conta){
        this.limite = limite;
        this.conta = conta;
    }

    @Override
    public void depositar(double valor) {
        this.conta.depositar(valor);
    }

    @Override
    public void sacar(double valor) {
        if(this.conta.saldo() + this.limite - valor < 0) {
            throw new IllegalStateException("Limite excedido");
        }
        this.conta.sacar(valor);
    }

    @Override
    public void transferir(Conta destino, double valor) {

    }

    @Override
    public double saldo() {
        return this.conta.saldo();
    }
}
