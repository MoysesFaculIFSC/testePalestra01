package banco.v10;

public interface Conta {
    void depositar (double valor);
    void sacar (double valor);
    void transferir (Conta destino, double valor);
    double saldo (); //imprimir
}
