package banco.v10;

public class ContaSemSaldoNegativo implements Conta{
    private Conta conta;

    public ContaSemSaldoNegativo(Conta conta){
        this.conta = conta;
    }

    @Override
    public void depositar(double valor) {
        this.conta.depositar(valor);
    }

    @Override
    public void sacar(double valor) {
        if(this.conta.saldo() - valor < 0){
            throw new IllegalStateException("Saldo insuficiente");
        }
        this.conta.sacar(valor);
    }

    @Override
    public void transferir(Conta destino, double valor) {
        this.sacar(valor);
        destino.depositar(valor);
    }

    @Override
    public double saldo() {
        return this.conta.saldo();
    }
}
