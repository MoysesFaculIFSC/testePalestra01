package banco.v10;

import banco.v10.ContaCorrente;

public class Main {
    public static void main(String[] args) {
        ContaPoupanca joao = new ContaPoupanca("Joao");
        joao.sacar(500);
        System.out.println(joao.saldo());

        Conta ana = new ContaSemSaldoNegativo(
                new ContaCorrente("Ana")
        );
        Conta ze = new ContaCorrente("Ze");
        new ContaSemSaldoNegativo(ze);

        ze.depositar(1000);

        System.out.println(ze.saldo());
        System.out.println(ana.saldo());

        ze.transferir(ana,5000);

        System.out.println(ze.saldo());
        System.out.println(ana.saldo());
    }
}
