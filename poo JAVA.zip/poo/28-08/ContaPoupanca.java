package banco.v10;

public class ContaPoupanca implements Conta {
    private double saldo;
    private String titular;

    public ContaPoupanca(String titular){
        this.saldo = 0.0;
        this.titular = titular;
    }

    @Override
    public void depositar(double valor) {
        this.saldo += valor;
    }

    @Override
    public void sacar(double valor) {
        this.saldo -= valor;
    }

    @Override
    public void transferir(Conta destino, double valor) {
        this.sacar(valor);
        destino.depositar(valor);
    }

    @Override
    public double saldo() {
        return this.saldo;
    }
}
