public interface Produto {
    String id();
    String nome();
    double preco();
}
