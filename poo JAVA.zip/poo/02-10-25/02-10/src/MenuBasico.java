import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MenuBasico implements Menu{
    private List<Opcao> opcoes;
    private String titulo;

    public MenuBasico(String titulo, Opcao ... opcoes){
        this.titulo = titulo;
        this.opcoes = new ArrayList<>(Arrays.asList(opcoes));
    }

    @Override
    public void adicionar(Opcao o) {

    }

    @Override
    public List<Opcao> opcoes() {
        return List.of();
    }

    @Override
    public String titulo() {
        return titulo;
    }

    @Override
    public void exibir() {
        while (true){
            for(Opcao opcao : this.opcoes){
                System.out.println(opcao.numero() + " - " + opcao.descricao());
            }
            System.out.println("opcao:");
            int escolha = Integer.parseInt(new Scanner(System.in).nextLine());
            Opcao selecionada = null;
            for(Opcao opcao : this.opcoes){
                if(opcao.numero() == escolha){
                    selecionada = opcao;
                    break;
                }
            }
            if (selecionada != null){
                selecionada.executar();
            } else {
                System.out.println("Opcao inválida");
            }
        }
    }
}
