public class ProdutoBasico implements Produto{
    private String id;
    private String nome;
    private double preco;

    public ProdutoBasico(String id, String nome, double preco){
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String nome() {
        return nome;
    }

    @Override
    public double preco() {
        return preco;
    }
}
