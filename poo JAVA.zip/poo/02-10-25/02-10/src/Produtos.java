import java.util.List;

public interface Produtos {
    void adicionar(Produto p);
    Produto buscarPorId(String id);
    void remover(String id);
    List<Produto> todos();
}
