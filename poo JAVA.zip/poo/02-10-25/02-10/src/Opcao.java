public interface Opcao {
    int numero();
    String descricao();
    void executar();
}
