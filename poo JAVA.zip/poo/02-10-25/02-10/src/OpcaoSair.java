public class OpcaoSair implements Opcao{
    private int numero;
    private String descricao;

    public OpcaoSair(int numero,String descricao){
        this.numero = numero;
        this.descricao = descricao;
    }

    @Override
    public int numero() {
        return this.numero;
    }

    @Override
    public String descricao() {
        return this.descricao;
    }

    @Override
    public void executar() {
        System.exit(0);
    }
}
