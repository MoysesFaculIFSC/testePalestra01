public class App {

    public static void main(String[] args) {
        ProdutosMemoria produtos = new ProdutosMemoria();

        OpcaoSair sair = new OpcaoSair(0, "Sair");


        new MenuBasico("Arquivo",
                new OpcaoSair(0, "Sair"),
                new OpcaoCadastrarProdutos(1, "Cadastrar Produtos")
                new OpcaoListarProdutos()
        ).exibir();


    }
}
