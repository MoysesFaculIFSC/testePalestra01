import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProdutosMemoria implements Produtos{
    //private List<Produto> produtos;
    private Map<String, Produto> produtos;

    public ProdutosMemoria(){
        //this.produtos = new ArrayList<>();
        this.produtos = new HashMap<>();
    }


    @Override
    public void adicionar(Produto p) {
        this.produtos.put(p.id(), p);
    }

    @Override
    public Produto buscarPorId(String id) {
        return this.produtos.get(id);
    }

    @Override
    public void remover(String id) {
         this.produtos.remove(id);

    }

    @Override
    public List<Produto> todos() {
        return new ArrayList<>(produtos.values());
    }

}
