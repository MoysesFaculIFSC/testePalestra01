import java.util.Scanner;

public class OpcaoListarProdutos implements Opcao{
    private int numero;
    private String descricao;
    private Produtos produtos;

    public OpcaoCadastrarProdutos(int numero,String descricao, Produtos produtos){
        this.numero = numero;
        this.descricao = descricao;
    }

    @Override
    public int numero() {
        return this.numero;
    }

    @Override
    public String descricao() {
        return this.descricao;
    }

    @Override
    public void executar() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Listagem:");
        //for (Produto )



        produtos.adicionar(new ProdutoBasico(id,nome,preco));

    }

}
