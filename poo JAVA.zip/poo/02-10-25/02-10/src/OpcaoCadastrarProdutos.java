import java.util.Scanner;

public class OpcaoCadastrarProdutos implements Opcao{
    private int numero;
    private String descricao;
    private Produtos produtos;

    public OpcaoCadastrarProdutos(int numero,String descricao, Produtos produtos){
        this.numero = numero;
        this.descricao = descricao;
    }

    @Override
    public int numero() {
        return this.numero;
    }

    @Override
    public String descricao() {
        return this.descricao;
    }

    @Override
    public void executar() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Id:");
        String id = scanner.nextLine();

        System.out.println("Nome:");
        String nome = scanner.nextLine();

        System.out.println("Preco:");
        double preco = Double.parseDouble(scanner.nextLine());


        produtos.adicionar(new ProdutoBasico(id,nome,preco));

    }
}
