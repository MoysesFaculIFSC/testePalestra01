package PostoExercicio;

public interface Combustivel {
    public double preco();
}
