package PostoExercicio;

public class Posto {
    double abastecer (double litros, Combustivel combustivel){
        return litros * combustivel.preco();
    }
}
