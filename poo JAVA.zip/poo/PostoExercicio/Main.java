package PostoExercicio;

public class Main {
    public static void main(String[] args) {
        Combustivel alcool = new Alcool(5);
        Gasolina gasolina = new Gasolina();
        Posto posto = new Posto();

        double  valor = posto.abastecer(10,gasolina);
    }
}
