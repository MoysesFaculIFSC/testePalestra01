package PostoExercicio;

public class Gasolina implements Combustivel{
    @Override
    public double preco() {
        return 6;
    }
}
