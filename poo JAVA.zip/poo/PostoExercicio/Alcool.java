package PostoExercicio;

public class Alcool implements Combustivel{
    private double preco;

    public Alcool (double preco){
        this.preco = preco;
    }

    @Override
    public double preco() {
        return this.preco;
    }
}
